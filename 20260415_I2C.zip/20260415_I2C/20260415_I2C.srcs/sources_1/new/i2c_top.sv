`timescale 1ns / 1ps

module i2c_top (
    input logic clk,
    input logic reset,

    input logic       master_cmd_start,
    input logic       master_cmd_write,
    input logic       master_cmd_read,
    input logic       master_cmd_stop,
    input logic [7:0] master_tx_data,
    input logic       master_ack_in,

    output logic [7:0] master_rx_data,
    output logic       master_done,
    output logic       master_ack_out,
    output logic       master_busy,

    input logic [6:0] slave_addr,
    input logic [7:0] slave_tx_data,

    output logic [7:0] slave_rx_data,
    output logic       slave_rx_valid,
    output logic       slave_tx_req
);

    wire scl;
    wire sda;

    // I2C 버스는 기본적으로 Open-Drain 방식을 사용하므로 풀업 저항이 필요합니다.
    // 작성하신 코드에 'sda = sda_o ? 1'bz : 1'b0;'가 적용되어 있으므로, 
    // High(1) 상태를 유지하기 위해 sda 라인에 풀업을 달아줍니다.
    pullup (sda);

    // 1. I2C Master 인스턴스화
    top_I2C_MASTER u_master (
        .clk      (clk),
        .reset    (reset),
        .cmd_start(master_cmd_start),
        .cmd_write(master_cmd_write),
        .cmd_read (master_cmd_read),
        .cmd_stop (master_cmd_stop),
        .tx_data  (master_tx_data),
        .ack_in   (master_ack_in),
        .rx_data  (master_rx_data),
        .done     (master_done),
        .ack_out  (master_ack_out),
        .busy     (master_busy),
        .scl      (scl),
        .sda      (sda)
    );

    // 2. I2C Slave 인스턴스화
    top_I2C_SLAVE u_slave (
        .clk       (clk),
        .reset     (reset),
        .slave_addr(slave_addr),
        .rx_data   (slave_rx_data),
        .rx_valid  (slave_rx_valid),
        .tx_data   (slave_tx_data),
        .tx_req    (slave_tx_req),
        .scl       (scl),
        .sda       (sda)
    );

endmodule
