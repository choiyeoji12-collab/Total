`timescale 1ns / 1ps

module top_slave (
    input logic clk,
    input logic reset,
    input logic [7:0] sw,
    output logic [7:0] led,
    output logic [3:0] fnd_digit,
    output logic [7:0] fnd_data,

    // I2C 외부 핀 (Pmod)
    input logic i2c_scl,
    inout logic i2c_sda
);

    logic [7:0] w_rx_data;
    logic [7:0] slave_tx_data;
    logic       rx_valid;
    assign led = w_rx_data;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            slave_tx_data <= 8'h00;
        end else if (rx_valid) begin
            slave_tx_data <= w_rx_data;
        end
    end

    top_I2C_SLAVE U_I2C_SLAVE (
        .clk       (clk),
        .reset     (reset),
        .slave_addr(7'h50),
        .rx_data   (w_rx_data),
        .rx_valid  (rx_valid),
        .tx_data   (slave_tx_data),
        .tx_req    (),
        .scl       (i2c_scl),
        .sda       (i2c_sda)
    );

    fnd_controller U_FND_CONTROLLER (
        .clk        (clk),
        .reset      (reset),
        .fnd_in_data({6'd0, w_rx_data}),
        .fnd_digit  (fnd_digit),
        .fnd_data   (fnd_data)
    );

endmodule
