`timescale 1ns / 1ps

module top_I2C_MASTER (
    input  logic       clk,
    input  logic       reset,
    // command port
    input  logic       cmd_start,
    input  logic       cmd_write, 
    input  logic       cmd_read,
    input  logic       cmd_stop,
    input  logic [7:0] tx_data,
    input  logic       ack_in,
    // internal output
    output logic [7:0] rx_data,
    output logic       done,
    output logic       ack_out,
    output logic       busy,
    // external i2c port
    output logic       scl,
    inout  logic       sda
);

    logic sda_o, sda_i;

    assign sda_i = sda;

    // Open Drain 구현
    // sda_o = 1이면 high impedance -> 외부 풀업 저항에 의해 high가 됨
    // sda_o = 0이면 스위치를 닫아 선을 그라운드로 끌어내림(0)
    assign sda   = sda_o ? 1'bz : 1'b0;

    i2c_master u_i2c_master (
        .*,
        .sda_o(sda_o),
        .sda_i(sda_i)
    );

endmodule

module i2c_master (
    input  logic       clk,
    input  logic       reset,
    // command port
    input  logic       cmd_start,
    input  logic       cmd_write,
    input  logic       cmd_read,
    input  logic       cmd_stop,
    input  logic [7:0] tx_data,
    input  logic       ack_in,
    // internal output
    output logic [7:0] rx_data,
    output logic       done,
    output logic       ack_out,
    output logic       busy,
    // external i2c port
    output logic       scl,
    output logic       sda_o,
    input  logic       sda_i
);

    typedef enum logic [2:0] {
        IDLE = 3'b000,
        START,
        WAIT_CMD,
        DATA,
        DATA_ACK,
        STOP
    } i2c_state_e;

    i2c_state_e state;

    logic [7:0] div_cnt;
    logic qtr_tick;
    logic scl_r, sda_r;     // register
    logic [1:0] step;       // 하나의 SCL 클럭을 4등분하여 타이밍을 쪼개는 카운터
    logic [7:0] tx_shift_reg, rx_shift_reg;
    logic [3:0] bit_cnt;
    logic is_read, ack_in_r;

    assign scl   = scl_r;
    assign sda_o = sda_r;
    assign busy  = (state != IDLE);

    // Clock Divider: 시스템 클럭을 분주하여 I2C 타이밍 기준(qtr_tick) 생성
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            div_cnt  <= 0;
            qtr_tick <= 1'b0;
        end else begin
            // 250번 카운트할 때마다 qtr_tick을 1번씩 튕겨줌
            // SCL 1주기는 이 qtr_tick이 4번 발생해야 완성됨
            if (div_cnt == 250 - 1) begin  // scl: 100khz
                div_cnt  <= 0;
                qtr_tick <= 1'b1;
            end else begin
                div_cnt  <= div_cnt + 1;
                qtr_tick <= 1'b0;
            end
        end
    end

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            state        <= IDLE;
            scl_r        <= 1'b1;
            sda_r        <= 1'b1;
            busy         <= 1'b0;
            step         <= 0;
            done         <= 1'b0;
            tx_shift_reg <= 0;
            rx_shift_reg <= 0;
            is_read      <= 1'b0;
            bit_cnt      <= 0;
            ack_in_r     <= 1'b1;
        end else begin
            done <= 1'b0;
            case (state)
                IDLE: begin
                    scl_r <= 1'b1;
                    sda_r <= 1'b1;
                    busy  <= 1'b0;
                    if (cmd_start) begin
                        state <= START;
                        step  <= 0;
                        //busy  <= 1'b1;
                    end
                end

                START: begin
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin 
                                sda_r <= 1'b1;
                                scl_r <= 1'b1;
                                step  <= 2'd1;
                            end

                            2'd1: begin 
                                sda_r <= 1'b0;
                                step  <= 2'd2;
                            end

                            2'd2: begin  
                                step <= 2'd3;
                            end

                            2'd3: begin  
                                scl_r <= 1'b0;
                                step  <= 2'd0;
                                done  <= 1'b1;
                                state <= WAIT_CMD;
                            end
                        endcase
                    end
                end

                WAIT_CMD: begin
                    step <= 0;
                    if (cmd_write) begin
                        tx_shift_reg <= tx_data;
                        bit_cnt      <= 0;
                        is_read      <= 1'b0;
                        state        <= DATA;
                    end else if (cmd_read) begin
                        rx_shift_reg <= 0;
                        bit_cnt      <= 0;
                        is_read      <= 1'b1;
                        ack_in_r     <= ack_in;
                        state        <= DATA;
                    end else if (cmd_stop) begin
                        state <= STOP;
                    end else if (cmd_start) begin
                        state <= START;
                    end
                end

                DATA: begin
                    // 8비트의 데이터를 직렬로 보내거나 읽는 구간
                    // SCL은 step에 따라 (0->1->1->0) 형태로 하나의 펄스를 만들어냄
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                // SCL=0, SDA 변경하는 구간
                                scl_r <= 1'b0;
                                // read면 선을 놓아주고(1), write면 MSB부터 씀
                                sda_r <= is_read ? 1'b1 : tx_shift_reg[7];
                                step  <= 2'd1;
                            end

                            2'd1: begin
                                // SCL을 High로 올리는 트랜지션 구간
                                scl_r <= 1'b1;
                                step  <= 2'd2;
                            end

                            2'd2: begin
                                // SCL=1, 데이터가 안정되어 샘플링(읽기)하는 구간
                                scl_r <= 1'b1;
                                if (is_read) begin
                                    // read 모드일 때 외부에서 들어오는 SDA 값을 읽어서 shift
                                    rx_shift_reg <= {rx_shift_reg[6:0], sda_i};
                                end
                                step <= 2'd3;
                            end

                            2'd3: begin
                                // SCL을 Low로 내리는 트랜지션 구간
                                scl_r <= 1'b0;
                                if (!is_read) begin
                                    // write 모드면 다음 비트 전송을 위해 데이터를 한 칸 밀어냄
                                    tx_shift_reg <= {tx_shift_reg[6:0], 1'b0};
                                end
                                step <= 2'd0;

                                if (bit_cnt == 7) begin
                                    state <= DATA_ACK;
                                end else begin
                                    bit_cnt <= bit_cnt + 1;
                                end
                            end
                        endcase
                    end
                end

                DATA_ACK: begin
                    // 9번째 클럭, 수신 측이 데이터를 잘 받았는지 확인하는 구간
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                scl_r <= 1'b0;
                                if (is_read) begin
                                    // Master가 수신자->자신이 설정해둔 ACK/NACK를 SDA에 띄움
                                    sda_r <= ack_in_r;
                                end else begin
                                    // Master가 송신자->slave의 ACK을 듣기 위해 선을 high-z로 놓아줌
                                    sda_r <= 1'b1;  // sda input, sda high impedence 설정
                                end
                                step <= 2'd1;
                            end

                            2'd1: begin
                                scl_r <= 1'b1;
                                step  <= 2'd2;
                            end

                            2'd2: begin     // 샘플링 시점
                                scl_r <= 1'b1;  
                                if (!is_read) begin  // ack 수신
                                    ack_out <= sda_i;   // slave가 보낸 응답(ack=0, nack=1)을 저장
                                end
                                if (is_read) begin
                                    rx_data <= rx_shift_reg;    // 8비트 모두 읽은 데이터를 최종 출력 포트로 전달
                                end
                                step <= 2'd3;
                            end

                            2'd3: begin
                                scl_r <= 1'b0;
                                done  <= 1'b1;
                                step  <= 2'd0;
                                state <= WAIT_CMD;
                            end
                        endcase
                    end
                end

                STOP: begin
                    // I2C stop 조건: SCL이 high일 때 SDA가 low->high로 올라감
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                sda_r <= 1'b0;
                                scl_r <= 1'b0;
                                step  <= 2'd1;
                            end

                            2'd1: begin
                                scl_r <= 1'b1;  // SCL을 먼저 올림
                                step  <= 2'd2;
                            end

                            2'd2: begin
                                sda_r <= 1'b1;  // SCL이 high인 상태에서 SDA를 올림 (stop 조건)
                                step  <= 2'd3;
                            end

                            2'd3: begin
                                step  <= 2'd0;
                                done  <= 1'b1;
                                state <= IDLE;
                            end
                        endcase
                    end
                end

                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
