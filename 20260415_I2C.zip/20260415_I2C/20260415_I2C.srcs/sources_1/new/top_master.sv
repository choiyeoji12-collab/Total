`timescale 1ns / 1ps

module top_master (
    input  logic       clk,
    input  logic       reset,
    input  logic [7:0] sw,
    input  logic       btn_start,
    output logic [7:0] led,
    output logic [3:0] fnd_digit,
    output logic [7:0] fnd_data,
    // I2C 외부 핀 (Pmod)
    output logic       i2c_scl,
    inout  logic       i2c_sda
);

    logic btn_start_pulse;
    logic cmd_start, cmd_write, cmd_read, cmd_stop;
    logic [7:0] tx_data_in;
    logic [7:0] rx_data;
    logic [7:0] readback_data;
    logic done, busy;

    localparam logic [6:0] SLAVE_ADDR = 7'h50;

    btn_debounce U_BTN_DEBOUNCE (
        .clk(clk), .reset(reset), .i_btn(btn_start), .o_btn(btn_start_pulse)
    );

    typedef enum logic [3:0] {
        IDLE,
        S_START_CMD, S_START_WAIT,
        S_ADDR_W_CMD, S_ADDR_W_WAIT,
        S_DATA_W_CMD, S_DATA_W_WAIT,
        S_RESTART_CMD, S_RESTART_WAIT,
        S_ADDR_R_CMD, S_ADDR_R_WAIT,
        S_DATA_R_CMD, S_DATA_R_WAIT,
        S_STOP_CMD, S_STOP_WAIT
    } state_t;
    state_t state;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            state <= IDLE;
            {cmd_start, cmd_write, cmd_read, cmd_stop} <= 4'b0000;
            tx_data_in <= 8'h0;
            readback_data <= 8'h00;
        end else begin
            {cmd_start, cmd_write, cmd_read, cmd_stop} <= 4'b0000;

            case (state)
                IDLE: if (btn_start_pulse) state <= S_START_CMD;

                S_START_CMD: begin
                    cmd_start <= 1'b1;
                    state <= S_START_WAIT;
                end
                S_START_WAIT: begin
                    if (done) state <= S_ADDR_W_CMD;
                end

                S_ADDR_W_CMD: begin
                    tx_data_in <= {SLAVE_ADDR, 1'b0};
                    cmd_write  <= 1'b1;
                    state <= S_ADDR_W_WAIT;
                end
                S_ADDR_W_WAIT: begin
                    if (done) state <= S_DATA_W_CMD;
                end

                S_DATA_W_CMD: begin
                    tx_data_in <= sw;
                    cmd_write  <= 1'b1;
                    state <= S_DATA_W_WAIT;
                end
                S_DATA_W_WAIT: begin
                    if (done) state <= S_RESTART_CMD;
                end

                S_RESTART_CMD: begin
                    cmd_start <= 1'b1;
                    state <= S_RESTART_WAIT;
                end
                S_RESTART_WAIT: begin
                    if (done) state <= S_ADDR_R_CMD;
                end

                S_ADDR_R_CMD: begin
                    tx_data_in <= {SLAVE_ADDR, 1'b1};
                    cmd_write  <= 1'b1;
                    state <= S_ADDR_R_WAIT;
                end
                S_ADDR_R_WAIT: begin
                    if (done) state <= S_DATA_R_CMD;
                end

                S_DATA_R_CMD: begin
                    cmd_read  <= 1'b1;
                    state <= S_DATA_R_WAIT;
                end
                S_DATA_R_WAIT: begin
                    if (done) begin
                        readback_data <= rx_data;
                        state <= S_STOP_CMD;
                    end
                end

                S_STOP_CMD: begin
                    cmd_stop <= 1'b1;
                    state <= S_STOP_WAIT;
                end
                S_STOP_WAIT: begin
                    if (done) state <= IDLE;
                end
            endcase
        end
    end

    top_I2C_MASTER U_I2C_MASTER (
        .clk(clk), .reset(reset),
        .cmd_start(cmd_start), .cmd_write(cmd_write), .cmd_read(cmd_read), .cmd_stop(cmd_stop),
        .tx_data(tx_data_in), .ack_in(1'b1),
        .rx_data(rx_data), .done(done), .ack_out(), .busy(busy),
        .scl(i2c_scl), .sda(i2c_sda)
    );

    assign led = readback_data;

    fnd_controller U_FND_CONTROLLER (
        .clk       (clk),
        .reset     (reset),
        .fnd_in_data({6'd0, readback_data}),
        .fnd_digit (fnd_digit),
        .fnd_data  (fnd_data)
    );

endmodule
