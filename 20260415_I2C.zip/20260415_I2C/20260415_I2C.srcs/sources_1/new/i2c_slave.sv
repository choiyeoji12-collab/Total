`timescale 1ns / 1ps

module top_I2C_SLAVE (
    input  logic       clk,
    input  logic       reset,
    input  logic [6:0] slave_addr,
    output logic [7:0] rx_data,
    output logic       rx_valid,
    input  logic [7:0] tx_data,
    output logic       tx_req,
    input  logic       scl,
    inout  logic       sda
);

    logic sda_o, sda_i;

    assign sda_i = sda;
    assign sda   = sda_o ? 1'bz : 1'b0;

    i2c_slave u_i2c_slave (
        .*,
        .sda_o(sda_o),
        .sda_i(sda_i)
    );

endmodule

module i2c_slave (
    input  logic       clk,
    input  logic       reset,
    // internal port
    input  logic [6:0] slave_addr,
    output logic [7:0] rx_data,
    output logic       rx_valid,
    input  logic [7:0] tx_data,
    output logic       tx_req,
    // external port
    input  logic       scl,
    output logic       sda_o,
    input  logic       sda_i
);

    typedef enum logic [2:0] {
        IDLE = 3'b000,
        START,
        ADDR,
        ADDR_ACK,
        DATA,
        DATA_ACK,
        STOP
    } i2c_state_e;

    i2c_state_e state;

    // Edge Detector (엣지 검출기)
    logic scl_d1, scl_d2;
    logic sda_d1, sda_d2;
    logic scl_rising, scl_falling;
    logic sda_falling, sda_rising;
    logic start, stop;

    logic [7:0] tx_shift_reg, rx_shift_reg;
    logic [3:0] bit_cnt;
    logic is_read;
    logic master_ack;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            scl_d1 <= 1'b1;
            scl_d2 <= 1'b1;
            sda_d1 <= 1'b1;
            sda_d2 <= 1'b1;
        end else begin
            scl_d1 <= scl;
            scl_d2 <= scl_d1;
            sda_d1 <= sda_i;
            sda_d2 <= sda_d1;
        end
    end

    assign scl_rising = ~scl_d2 & scl_d1;  // 상승 엣지
    assign scl_falling = scl_d2 & ~scl_d1;  // 하강 엣지
    assign sda_rising = ~sda_d2 & sda_d1;
    assign sda_falling = sda_d2 & ~sda_d1;

    // i2c 특수 조건
    // SCL이 안정적으로 떠있을 떄(1), SDA가 떨어지면 start, 올라가면 stop
    assign start = scl_d2 & sda_falling;
    assign stop = scl_d2 & sda_rising;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            state        <= IDLE;
            sda_o        <= 1'b1;
            rx_data      <= 8'h0;
            rx_valid     <= 1'b0;
            tx_req       <= 1'b0;
            tx_shift_reg <= 0;
            rx_shift_reg <= 0;
            bit_cnt      <= 0;
            is_read      <= 1'b0;
            master_ack   <= 1'b1;
        end else begin
            rx_valid <= 1'b0;
            tx_req   <= 1'b0;

            if (stop) begin
                state <= STOP;
            end else if (start) begin
                state <= START;

            end else begin
                case (state)
                    IDLE: begin
                        sda_o <= 1'b1;
                        //if (start) begin
                        //    state <= START
                        //end
                    end

                    START: begin
                        bit_cnt <= 0;
                        sda_o   <= 1'b1;
                        state   <= ADDR;
                    end

                    ADDR: begin
                        // [데이터 읽기] SCL이 상승하는 순간에만 SDA 값을 읽음 
                        if (scl_rising) begin
                            // 왼쪽으로 한 킨씩 밀면서 LSB에 방금 읽은 데이터 입력
                            rx_shift_reg <= {rx_shift_reg[6:0], sda_d1};
                            bit_cnt <= bit_cnt + 1;
                            // 8비트를 다 모았고 SCL이 1에서 0으로 다시 내려가는 순간
                        end else if (scl_falling && bit_cnt == 8) begin
                            // 모아둔 8비트 중 상위 7비트가 내 주소와 일치하는가
                            if (rx_shift_reg[7:1] == slave_addr) begin
                                sda_o <= 1'b0; 
                                is_read <= rx_shift_reg[0]; // 마지막 1비트로 read/write 방향 결정
                                state <= ADDR_ACK;
                            end else begin
                                sda_o <= 1'b1; 
                                state <= IDLE;
                            end
                        end
                    end

                    ADDR_ACK: begin
                        // ACK를 master가 확인하고 SCL을 내림
                        if (scl_falling) begin
                            bit_cnt <= 0;
                            state   <= DATA;
                            if (is_read) begin
                                // slave -> master
                                tx_shift_reg <= tx_data;
                                sda_o <= tx_data[7];  // MSB부터 선에 띄움
                                tx_req       <= 1'b1;   // 다음 데이터 준비해라
                            end else begin
                                // master -> slave
                                sda_o <= 1'b1;    // master가 선을 조작할 수 있게 놔줌
                            end
                        end
                    end

                    DATA: begin
                        if (is_read == 1'b0) begin
                            // write (master -> slave)
                            if (scl_rising) begin
                                rx_shift_reg <= {rx_shift_reg[6:0], sda_d2};
                                bit_cnt      <= bit_cnt + 1;
                            end else if (scl_falling && bit_cnt == 8) begin
                                sda_o    <= 1'b0; 
                                rx_data  <= rx_shift_reg;   // 받은 데이터를 내부에 전달
                                rx_valid <= 1'b1; 
                                state    <= DATA_ACK;
                            end
                        end else begin
                            // read (slave -> master)
                            if (scl_rising) begin
                                bit_cnt <= bit_cnt + 1;
                            end else if (scl_falling) begin
                                if (bit_cnt == 8) begin
                                    sda_o <= 1'b1;
                                    state <= DATA_ACK;
                                end else begin
                                    tx_shift_reg <= {tx_shift_reg[6:0], 1'b0};
                                    sda_o        <= tx_shift_reg[6];
                                end
                            end
                        end
                    end

                    DATA_ACK: begin
                        if (is_read == 1'b0) begin
                            if (scl_falling) begin
                                sda_o   <= 1'b1;
                                bit_cnt <= 0;
                                state   <= DATA;
                            end
                        end else begin
                            if (scl_rising) begin
                                master_ack <= sda_d2;
                            end else if (scl_falling) begin
                                if (master_ack == 1'b0) begin
                                    bit_cnt      <= 0;
                                    tx_shift_reg <= tx_data;
                                    sda_o        <= tx_data[7];
                                    tx_req       <= 1'b1;
                                    state        <= DATA;
                                end else begin
                                    sda_o <= 1'b1;
                                    state <= IDLE;
                                end
                            end
                        end
                    end

                    STOP: begin
                        sda_o <= 1'b1;
                        state <= IDLE;
                    end

                    default: begin
                        state <= IDLE;
                    end
                endcase
            end
        end
    end


endmodule
