/*
 * ap_main.c
 *
 *  Created on: 2026. 4. 28.
 *      Author: kccistc
 */

#include "xil_printf.h"

#include "ap_main.h"
#include "UpCounter/UpCounter.h"
#include "../HAL/TMR/TMR.h"
#include "TimeClock/TimeClock.h"
#include "interrupt.h"

void ap_init()
{
	UpCounter_Init();
	TimeClock_Init();
	SetupInterruptSystem();

	// 1Mhz -> 1us �������� count ����, interrupt �߻� �� ��
	TMR_SetPSC(TMR0, 100-1);
	TMR_SetARR(TMR0, 0xffffffff);
	TMR_StopIntr(TMR0);
	TMR_StartTimer(TMR0);

	// 1khz -> 1ms �������� interrupt �߻�
	TMR_SetPSC(TMR1, 100-1);
	TMR_SetARR(TMR1, 1000-1);
	TMR_StartIntr(TMR1);
	TMR_StartTimer(TMR1);

	// 100hz -> 10ms �������� interrupt �߻�
	TMR_SetPSC(TMR2, 100-1);
	TMR_SetARR(TMR2, 10000-1);
	TMR_StartIntr(TMR2);
	TMR_StartTimer(TMR2);
}

void ap_excute()
{
	while (1)
	{
		//UpCounter_Excute();
		TimeClock_Excute();
	}
}
